//
// Created by cahill on 19/05/2019.
//

#ifndef NOTE_H
#define NOTE_H

/**
* Forward declaration of the note struct.
*/
struct note
{
    char* title;
    char* contents;
    int priority;
    struct note* next;
};

/**
* Dynamically allocates a single note struct. A note comprises a title string,
* contents string, and a priority. Copies of the title and
* contents strings set on the note before returning a struct note pointer.
*/
struct note* createNote(char *title, char *contents, int priority)
{
    struct note* temp = (struct note*)malloc(sizeof(struct note*));
    temp->title = (char*)malloc(sizeof(char*)*strlen(title));
    strcpy(temp->title, title);
    temp->contents = (char*)malloc(sizeof(char*)*strlen(contents));
    strcpy(temp->contents, contents);
    temp->priority = priority;
    temp->next = NULL;
    return temp;
}

/**
* Returns the priority of for the given note. The lower the integer
* value, the higher the priority of the note.
*/
int getPriority(struct note *note)
{
    return note->priority;
}

/**
* Returns the title of the given note.
*/
char* getTitle(struct note *note)
{
    return note->title;
}

/**
* Returns the contents of the given note.
*/
char* getContents(struct note *note)
{
    return note->contents;
}

/**
* Returns the first line of content for the given note, i.e. all characters up
* to but not including a line break character.
*/
char* head(struct note *note)
{
    return strtok(note->contents, "\n");
}

/**
* Returns the word count for the given note. Words are separated by whitespace
* or line-break characters; words can also by separated by punctuation characters such as period '.'
*/
unsigned int getWordCount(struct note *note)
{
    unsigned int count = 0;
    for (unsigned int i = 0; i < strlen(note->contents); i++)
    {
        if (note->contents[i] == ',')
        {
            count++;
            if (note->contents[i + 1] == ' ')
                i++;
        }
        else if (note->contents[i] == '.')
        {
            count++;
            if (note->contents[i + 1] == '\n')
                i++;
            if (note->contents[i + 1] == ' ')
                i++;
        }
        else if (note->contents[i] == ' ')
        {
            count++;
        }
    }
    return count;
}

/**
* Frees any memory associated with the given note.
*/
void dispose(struct note *note)
{
    free(note->contents);
    free(note->title);
    free(note);
}

#endif