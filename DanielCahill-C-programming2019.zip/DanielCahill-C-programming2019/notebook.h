//
// Created by cahill on 19/05/2019.
//

#ifndef NOTEBOOK_H
#define NOTEBOOK_H

#include "note.h"

/**
* Forward declaration of the notebook struct.
*/
struct notebook
{
    struct note *head;
    struct note *tail;
    int no_of_nodes;
};

/**
* Dynamically allocates a single notebook struct. A note comprises a  linked-list
* of notes.
*/
struct notebook* createNotebook()
{
    struct notebook* temp = (struct notebook*)malloc(sizeof(struct notebook*));
    temp->head = NULL;
    temp->tail = NULL;
    temp->no_of_nodes = 0;
    return temp;
}

/**
* Adds the given note to the end of the given notebook's note list.
*/
void addNote(struct notebook *notebook, struct note *note)
{
    if (notebook->head == NULL)
    {
        notebook->head = note;
        notebook->no_of_nodes++;
    }
    else
    {
        struct note* temp = notebook->head;
        int count = 0;
        while (temp->next != NULL && count++ < notebook->no_of_nodes)
            temp = temp->next;
        temp->next = note;
        notebook->no_of_nodes++;
    }
}

/**
* Removes the given note from the given notebook's note list, if it is present.
*/
void removeNote(struct notebook *notebook, struct note *note)
{
    if (notebook->no_of_nodes == 0)
        return;
    if (notebook->head == note)
    {
        notebook->head = notebook->head->next;
        notebook->no_of_nodes--;
        return;
    }

    struct note* temp = notebook->head->next;
    struct note* prev = notebook->head;

    while (temp != NULL)
    {
        if (temp == note)
        {
            prev->next = temp->next;
            temp->next = NULL;
            notebook->no_of_nodes--;
            return;
        }
        prev = temp;
        temp = temp->next;
    }
}

/**
* Searches the given notebook's note list for the first note whose content contains the
* given string. If such a note exists, a pointer to same is returned; else this funcion returns NULL.
*/
struct note* findByContent(struct notebook *notebook, char *str)
{
    if (notebook->no_of_nodes == 0)
        return NULL;

    struct note* temp = notebook->head;
    int count = 0;
    while (temp != NULL && count !=notebook->no_of_nodes)
    {
        if (strstr(temp->contents, str)!=NULL)
            return temp;
        temp = temp->next;
        count++;
    }
    return NULL;
}

/**
* Searches the given notebook's note list for the first note whose title contains the
* given string. If such a note exists, a pointer to same is returned; else this funcion returns NULL.
*/
struct note* findByTitle(struct notebook *notebook, char *str)
{
    if (notebook->no_of_nodes == 0)
        return NULL;

    struct note* temp = notebook->head;
    int count = 0;
    while (temp != NULL && count != notebook->no_of_nodes)
    {
        if (!strcmp(temp->title, str))
            return temp;
        temp = temp->next;
        count++;
    }
    return NULL;
}

/**
* Returns the number of notes contained in the given notebook's note list.
*/
int countNotes(struct notebook *notebook)
{
    return notebook->no_of_nodes;
}

/**
* Removes all notes from the given notebook's note list.
*/
void clearNotes(struct notebook *notebook)
{
    struct note *ptr = notebook->head;
    struct note *temp = NULL;

    /* Checking for empty list */
    if (notebook->head == NULL)
        return;

    while (ptr->next != NULL)
    {
        temp = ptr;
        ptr = ptr->next;
        temp->next = NULL;
    }
    notebook->head = NULL;
    notebook->no_of_nodes = 0;
}

/* function to swap data of two nodes a and b*/
void swap(struct notebook *notebook,struct note *a, struct note *b)
{
    struct note *temp = a;
    temp->next = b->next;
    a = b;
    a->next = temp;
    b = temp;
    if (notebook->head == b)
        notebook->head = a;
}

/**
* Sorts all notes in the given notebook's note list. Notes are sorted by priority; a lower priority
* value should appear earlier in the sorted list, i.e. a note with priority 1 will appear before a note with priority 2.
* Any sort algorithm may be applied. Bubblesort is the suggested sort implementation.
*/
void sortByPriority(struct notebook *notebook)
{
    /* Checking for empty list */
    if (notebook->head == NULL)
        return;

    for (int i = 0; i<notebook->no_of_nodes-1;i++)
    {
        struct note *ptr = notebook->head;

        for (int j = 0; j<notebook->no_of_nodes - i - 2;j++)
        {
            if (ptr->priority>ptr->next->priority)
                swap(notebook,ptr, ptr->next);
            ptr = ptr->next;
        }
    }
}

/**
* Returns a pointer to the note at the given index in the given notebook's note list. If an invalid index is passed to
* this function it will return NULL.
*/
struct note* getNoteAt(struct notebook *notebook, int index)
{
    if (notebook->no_of_nodes < index)
        return NULL;

    struct note* temp = notebook->head;
    int count = 0;
    while (count != index)
    {
        temp = temp->next;
        count++;
    }
    return temp;

}

#endif